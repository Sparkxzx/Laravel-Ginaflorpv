@extends('errors::layout')
@section('title', '404')
@section('message' , 'Página no encontrada')
