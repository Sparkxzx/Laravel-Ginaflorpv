@extends('site.app')
@section('title', 'Inicio')

@section('content')
<section class="section-pagetop bg-dark">
    <div class="container clearfix">
        <h2 class="title-page">Inicio</h2>
    </div>
</section>
    <div class="container">
        <div class="container-fluid">
            <div class="card-body">
                <div class="container">
                    <br>
                    <H2 class="">Bienvenido a: Gina flor P.V.
                    <p style="font-size: 20px; text-align: justify;" class="card-body">
                        <br>
                         Sí usted desea realizar una compra seleccione la categoría de su preferencia, Y posteriormente
                        <br>
                        agréguelo a su carrito de compras para poder realizar su págo correspondiente.
                    </p>
                    <p style="font-size: 20px; text-align: justify;" class="card-body"> Para más infomación puede contactarnos o de igual forma revisar nuestros términos y condiciones.
                        <br>También puede consultar las redes sociales, los horarios y la ubicación del local.

                    </p>
                </H2>

                </div>
            </div>
        </div>
    </div>
@stop

