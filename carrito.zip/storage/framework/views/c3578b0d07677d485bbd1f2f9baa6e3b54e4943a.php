<link rel="shortcut icon" type="image" href="<?php echo e(asset('assets/images/logoai.png')); ?>">
<link href="<?php echo e(asset('frontend/css/bootstrap.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('frontend/fonts/fontawesome/css/fontawesome-all.min.css')); ?>" type="text/css" rel="stylesheet">
<link href="<?php echo e(asset('frontend/plugins/fancybox/fancybox.min.css')); ?>" type="text/css" rel="stylesheet">
<link href="<?php echo e(asset('frontend/plugins/owlcarousel/assets/owl.carousel.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('frontend/plugins/owlcarousel/assets/owl.theme.default.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('frontend/css/ui.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('frontend/css/responsive.css')); ?>" rel="stylesheet" media="only screen and (max-width: 1200px)" />
<?php echo $__env->yieldPushContent('scripts'); ?>
<?php /**PATH C:\laragon\www\carrito\resources\views/site/partials/styles.blade.php ENDPATH**/ ?>