<!-- ========================= FOOTER ========================= -->
<footer class="section-footer bg-dark white">
    <div class="container">
        <section class="footer-top padding-top">
            <div class="row">
                <aside class="col-sm-3 col-md-3 white">
                    <h5 ><a style="color: white;" href="<?php echo e(route('terminos')); ?>">Términos y privacidad</a></h5>

                </aside>
                <aside class="col-sm-3  col-md-3 white">
                    <h5 ><a style="color: white;" href="<?php echo e(route('nosotros')); ?>">Sobre nosotros</a></h5>
                </aside>
                <aside class="col-sm-3  col-md-3 white">
                    <h5><a style="color: white;" href="<?php echo e(route('negocio')); ?>">Sobre el negocio</a></h5>
                </aside>
                <aside class="col-sm-3">
                    <h5 ><a  style="color: white;" href="<?php echo e(route('formulario')); ?>">Contacto</a></h5>
                </aside>
            </div>
            <!-- row.// -->
            <br>
        </section>
        <!-- //footer-top -->
    </div>
    <!-- //container -->
</footer>
<!-- ========================= FOOTER END // ========================= -->
<?php /**PATH C:\laragon\www\carrito\resources\views/site/partials/footer.blade.php ENDPATH**/ ?>