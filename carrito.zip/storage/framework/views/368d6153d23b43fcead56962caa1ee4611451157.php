<?php $__env->startSection('title', 'Shopping Cart'); ?>
<?php $__env->startSection('content'); ?>
<style>
 #todo{
     background: #ccc;
     padding: 50px;
 }
 h1,h2,h3, h5{
    line-height : 40px;
    text-align: justify;
 }

</style>
<div id="todo">
    <h1>Sobre nosotros</h1><br>
    <h3>Historia</h3>
<h5>
    Iniciamos en el año 2001 ubicados en la avenida primera de Mayo #59, ofreciendo la venta de flores, debido a que las ventas lograron alcanzar nuestras expectativas en 2010 implementamos el servicio de decoración a domicilio, de esta manera ampliando nuestro negocio. <br>
Actualmente contamos con 3 locales en la misma ubicación (avenida 1° de Mayo #59, costado del panteón municipal), ofrecemos venta de flor natura y artificial, igualmente servicios de decoración de templos y salones incluyendo la colocación de cortinajes y tela, además de contar con un excelente equipo de trabajo y brindar productos de calidad.
</h5><br>
<h3>Misión</h3>
<h5>
    Brindar productos y servisios de calidad a nuetsro clientes.
</h5><br>
<h3>Visión</h3>
<h5>
    Ser un negocio distinguido en la ciudad de acambaro y tener un mayor reocnocimiento social.
</h5><br>
<h3>Valores</h3>
<h5>
    Dentro del negocio GinaFlor P.V nos hacemos responsables de los resultados que entregamos,
los productos y/o servicios que manejamod se realizan de la mejor forma para cumplir con las expectativas de los clienres, es por ello que
aplicamos los diguiente svalores:
<ul>
    <li>
        Integridad</li>
        <li>Respeto</li>
        <li>Trabajo en equipo</li>
        <li>Calidad</li>
        <li>Honestidad</li>
</ul>
</h5><br>


</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('site.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\carrito\resources\views/usuario/nosotros.blade.php ENDPATH**/ ?>