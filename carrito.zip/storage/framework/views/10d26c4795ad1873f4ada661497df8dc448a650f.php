<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title'); ?> Contactos <?php $__env->stopSection(); ?>
<div class="app-title">
    <div>
        <h1><i class="fa fa-tags"></i> Contactos</h1>
        <p>Lista de Contactos</p>
    </div>

</div>
<div class="row">
    <div class="col-md-12">
        <div class="tile">
            <div class="tile-body">
                <table class="table table-hover table-bordered" id="sampleTable">
	<thead class="thead-info">
		<tr>
			<th>#</th>
			<th>Nombre del usuario</th>
			<th class="text-center">Correo</th>
			<th class="text-center">Télefono celular</th>
			<th class="text-center">Asunto</th>
			<th class="text-center">Mensaje</th>
		</tr>
	</thead>
<tbody >
		<?php $__currentLoopData = $contacto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contacto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td ><?php echo e($contacto->id); ?></td>
			<td ><?php echo e($contacto->nombre); ?></td>
			<td class="text-center"><?php echo e($contacto->email); ?></td>
			<td class="text-center"><?php echo e($contacto->telefono); ?></td>
			<td class="text-center"><?php echo e($contacto->asunto); ?></td>
			<td class="text-center"><?php echo e($contacto->mensaje); ?></td>
			<td>

				<form method="post" action="<?php echo e(url('/admin/contacto/'.$contacto->id)); ?>">
					<?php echo csrf_field(); ?>

					<?php echo e(method_field('DELETE')); ?>

					<button class="btn btn-sm btn-danger" type="submit" onclick="return confirm('¿Eliminar mensaje?');">Eliminar</button>

				</form>

				</td>
				<td><button class="btn btn-sm btn-warning"><a href="https://mail.google.com/">Responder</a></button></td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
        </div>
        </div>
    </div>
</div>
</table>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript" src="<?php echo e(asset('backend/js/plugins/jquery.dataTables.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('backend/js/plugins/dataTables.bootstrap.min.js')); ?>"></script>
    <script type="text/javascript">$('#sampleTable').DataTable();</script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\carrito\resources\views/admin/contacto/index.blade.php ENDPATH**/ ?>