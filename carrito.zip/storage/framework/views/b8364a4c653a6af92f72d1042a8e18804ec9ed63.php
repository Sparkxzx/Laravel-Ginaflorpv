<script src="<?php echo e(asset('frontend/js/jquery-2.0.0.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('frontend/js/bootstrap.bundle.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('frontend/plugins/fancybox/fancybox.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('frontend/plugins/owlcarousel/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/js/script.js')); ?>" type="text/javascript"></script>
<?php /**PATH C:\laragon\www\carrito\resources\views/site/partials/scripts.blade.php ENDPATH**/ ?>