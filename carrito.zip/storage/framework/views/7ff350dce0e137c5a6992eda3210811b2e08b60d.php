<header class="section-header">
    <section style="background-color: rgba(26, 10, 56, 0.53)" class="header-main">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-3">
                    <div class="brand-wrap">
                        <a href="<?php echo e(url('/')); ?>">
                            <img class="logo" src="<?php echo e(asset('assets/images/logo.png')); ?>" alt="logo">
                        </a>
                    </div>
                </div>
                <div class="col-lg-9 col-sm-6">
                    <div class="widgets-wrap d-flex justify-content-end">
                        <div class="widget-header">
                            <a href="<?php echo e(route('checkout.cart')); ?>" class="icontext">
                                <div class="icon-wrap icon-xs bg2 round text-secondary"><i
                                        class="fa fa-shopping-cart"></i></div>
                                <div class="text-wrap">
                                    <small style="color:white;"><?php echo e($cartCount); ?> Arreglos</small>
                                </div>
                            </a>
                        </div>
                        <?php if(auth()->guard()->guest()): ?>
                            <div class="widget-header">
                                <a href="<?php echo e(route('login')); ?>" class="ml-1 icontext">
                                    <div class="icon-wrap icon-xs bg-primary round text-white"><i class="fa fa-user"></i></div>
                                    <div style="color:white;" class="text-wrap"><span>Ingresar</span></div>
                                </a>
                            </div>
                            <div class="widget-header">
                                <a href="<?php echo e(route('register')); ?>" class="ml-1 icontext">
                                    <div class="icon-wrap icon-xs bg-success round text-white"><i class="fa fa-user"></i></div>
                                    <div style="color:white;" class="text-wrap"><span>Registrarte</span></div>
                                </a>
                            </div>
                        <?php else: ?>
                            <ul class="navbar-nav ml-3">
                                <li class="nav-item dropdown">
                                    <a style="color:white;" id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                        <?php echo e(Auth::user()->full_name); ?> <span class="caret"></span>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                        <a class="dropdown-item" href="<?php echo e(route('account.orders')); ?>">Órdenes</a>
                                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                           onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                            <?php echo e(__('Cerrar sesión')); ?>

                                        </a>
                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                            <?php echo csrf_field(); ?>
                                        </form>
                                    </div>
                                </li>
                            </ul>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php echo $__env->make('site.partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</header>
<?php /**PATH C:\laragon\www\carrito\resources\views/site/partials/header.blade.php ENDPATH**/ ?>